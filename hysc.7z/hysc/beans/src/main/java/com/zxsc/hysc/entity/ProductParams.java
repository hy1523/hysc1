package com.zxsc.hysc.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

/**
 * 表名：product_params
*/
@Table(name = "product_params")
public class ProductParams {
    @Id
    @Column(name = "param_id")
    private Integer paramId;

    @Column(name = "product_id")
    private Integer productId;

    @Column(name = "product_place")
    private String productPlace;

    @Column(name = "foot_penond")
    private String footPenond;

    private String brand;

    @Column(name = "factory_name")
    private String factoryName;

    @Column(name = "factory_address")
    private String factoryAddress;

    @Column(name = "packaging_method")
    private String packagingMethod;

    private Double weight;

    @Column(name = "storage_method")
    private String storageMethod;

    @Column(name = "eat_method")
    private String eatMethod;

    @Column(name = "create_time")
    private Date createTime;

    @Column(name = "update_time")
    private Date updateTime;

    /**
     * @return paramId
     */
    public Integer getParamId() {
        return paramId;
    }

    /**
     * @param paramId
     */
    public void setParamId(Integer paramId) {
        this.paramId = paramId;
    }

    /**
     * @return productId
     */
    public Integer getProductId() {
        return productId;
    }

    /**
     * @param productId
     */
    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    /**
     * @return productPlace
     */
    public String getProductPlace() {
        return productPlace;
    }

    /**
     * @param productPlace
     */
    public void setProductPlace(String productPlace) {
        this.productPlace = productPlace == null ? null : productPlace.trim();
    }

    /**
     * @return footPenond
     */
    public String getFootPenond() {
        return footPenond;
    }

    /**
     * @param footPenond
     */
    public void setFootPenond(String footPenond) {
        this.footPenond = footPenond == null ? null : footPenond.trim();
    }

    /**
     * @return brand
     */
    public String getBrand() {
        return brand;
    }

    /**
     * @param brand
     */
    public void setBrand(String brand) {
        this.brand = brand == null ? null : brand.trim();
    }

    /**
     * @return factoryName
     */
    public String getFactoryName() {
        return factoryName;
    }

    /**
     * @param factoryName
     */
    public void setFactoryName(String factoryName) {
        this.factoryName = factoryName == null ? null : factoryName.trim();
    }

    /**
     * @return factoryAddress
     */
    public String getFactoryAddress() {
        return factoryAddress;
    }

    /**
     * @param factoryAddress
     */
    public void setFactoryAddress(String factoryAddress) {
        this.factoryAddress = factoryAddress == null ? null : factoryAddress.trim();
    }

    /**
     * @return packagingMethod
     */
    public String getPackagingMethod() {
        return packagingMethod;
    }

    /**
     * @param packagingMethod
     */
    public void setPackagingMethod(String packagingMethod) {
        this.packagingMethod = packagingMethod == null ? null : packagingMethod.trim();
    }

    /**
     * @return weight
     */
    public Double getWeight() {
        return weight;
    }

    /**
     * @param weight
     */
    public void setWeight(Double weight) {
        this.weight = weight;
    }

    /**
     * @return storageMethod
     */
    public String getStorageMethod() {
        return storageMethod;
    }

    /**
     * @param storageMethod
     */
    public void setStorageMethod(String storageMethod) {
        this.storageMethod = storageMethod == null ? null : storageMethod.trim();
    }

    /**
     * @return eatMethod
     */
    public String getEatMethod() {
        return eatMethod;
    }

    /**
     * @param eatMethod
     */
    public void setEatMethod(String eatMethod) {
        this.eatMethod = eatMethod == null ? null : eatMethod.trim();
    }

    /**
     * @return createTime
     */
    public Date getCreateTime() {
        return createTime;
    }

    /**
     * @param createTime
     */
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    /**
     * @return updateTime
     */
    public Date getUpdateTime() {
        return updateTime;
    }

    /**
     * @param updateTime
     */
    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }
}