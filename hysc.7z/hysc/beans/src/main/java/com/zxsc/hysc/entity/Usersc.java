package com.zxsc.hysc.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.util.Date;

/**
 * 表名：usersc
*/
public class Usersc {
    @Id
    @Column(name = "user_id")
    private Integer userId;

    private String username;

    private String password;

    private String nickname;

    private String realname;

    @Column(name = "user_img")
    private String userImg;

    @Column(name = "user_mobile")
    private String userMobile;

    @Column(name = "user_email")
    private String userEmail;

    @Column(name = "user_sex")
    private String userSex;

    @Column(name = "user_birth")
    private String userBirth;

    @Column(name = "user_regtime")
    private Date userRegtime;

    @Column(name = "user_modtime")
    private Date userModtime;

    /**
     * @return userId
     */
    public Integer getUserId() {
        return userId;
    }

    /**
     * @param userId
     */
    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    /**
     * @return username
     */
    public String getUsername() {
        return username;
    }

    /**
     * @param username
     */
    public void setUsername(String username) {
        this.username = username == null ? null : username.trim();
    }

    /**
     * @return password
     */
    public String getPassword() {
        return password;
    }

    /**
     * @param password
     */
    public void setPassword(String password) {
        this.password = password == null ? null : password.trim();
    }

    /**
     * @return nickname
     */
    public String getNickname() {
        return nickname;
    }

    /**
     * @param nickname
     */
    public void setNickname(String nickname) {
        this.nickname = nickname == null ? null : nickname.trim();
    }

    /**
     * @return realname
     */
    public String getRealname() {
        return realname;
    }

    /**
     * @param realname
     */
    public void setRealname(String realname) {
        this.realname = realname == null ? null : realname.trim();
    }

    /**
     * @return userImg
     */
    public String getUserImg() {
        return userImg;
    }

    /**
     * @param userImg
     */
    public void setUserImg(String userImg) {
        this.userImg = userImg == null ? null : userImg.trim();
    }

    /**
     * @return userMobile
     */
    public String getUserMobile() {
        return userMobile;
    }

    /**
     * @param userMobile
     */
    public void setUserMobile(String userMobile) {
        this.userMobile = userMobile == null ? null : userMobile.trim();
    }

    /**
     * @return userEmail
     */
    public String getUserEmail() {
        return userEmail;
    }

    /**
     * @param userEmail
     */
    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail == null ? null : userEmail.trim();
    }

    /**
     * @return userSex
     */
    public String getUserSex() {
        return userSex;
    }

    /**
     * @param userSex
     */
    public void setUserSex(String userSex) {
        this.userSex = userSex == null ? null : userSex.trim();
    }

    /**
     * @return userBirth
     */
    public String getUserBirth() {
        return userBirth;
    }

    /**
     * @param userBirth
     */
    public void setUserBirth(String userBirth) {
        this.userBirth = userBirth == null ? null : userBirth.trim();
    }

    /**
     * @return userRegtime
     */
    public Date getUserRegtime() {
        return userRegtime;
    }

    /**
     * @param userRegtime
     */
    public void setUserRegtime(Date userRegtime) {
        this.userRegtime = userRegtime;
    }

    /**
     * @return userModtime
     */
    public Date getUserModtime() {
        return userModtime;
    }

    /**
     * @param userModtime
     */
    public void setUserModtime(Date userModtime) {
        this.userModtime = userModtime;
    }
}