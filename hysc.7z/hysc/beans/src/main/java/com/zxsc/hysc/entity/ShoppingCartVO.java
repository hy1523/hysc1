package com.zxsc.hysc.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

/**
 * 表名：shopping_cart
*/
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "shopping_cart")
public class ShoppingCartVO {
    /**
     * 主键
     */
    @Id
    @Column(name = "cart_id")
    private Integer cartId;

    /**
     * 商品id
     */
    @Column(name = "product_id")
    private Integer productId;

    /**
     * skuid
     */
    @Column(name = "sku_id")
    private Integer skuId;

    /**
     * 选择的套餐属性
     */
    @Column(name = "sku_props")
    private String skuProps;

    /**
     * 用户id
     */
    @Column(name = "user_id")
    private Integer userId;

    /**
     * 购物车商品数量
     */
    @Column(name = "cart_num")
    private Integer cartNum;

    /**
     * 添加购物车时间
     */
    @Column(name = "cart_time")
    private Date cartTime;

    /**
     * 添加购物车的商品价格
     */
    @Column(name = "product_price")
    private Integer productPrice;

    private String productName;
    private String productImg;
    private String skuName;
    private int skuStock;//库存信息

    /**
     * 获取主键
     *
     * @return cartId - 主键
     */
    public Integer getCartId() {
        return cartId;
    }

    /**
     * 设置主键
     *
     * @param cartId 主键
     */
    public void setCartId(Integer cartId) {
        this.cartId = cartId;
    }

    /**
     * 获取商品id
     *
     * @return productId - 商品id
     */
    public Integer getProductId() {
        return productId;
    }

    /**
     * 设置商品id
     *
     * @param productId 商品id
     */
    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    /**
     * 获取skuid
     *
     * @return skuId - skuid
     */
    public Integer getSkuId() {
        return skuId;
    }

    /**
     * 设置skuid
     *
     * @param skuId skuid
     */
    public void setSkuId(Integer skuId) {
        this.skuId = skuId;
    }

    /**
     * 获取选择的套餐属性
     *
     * @return skuProps - 选择的套餐属性
     */
    public String getSkuProps() {
        return skuProps;
    }

    /**
     * 设置选择的套餐属性
     *
     * @param skuProps 选择的套餐属性
     */
    public void setSkuProps(String skuProps) {
        this.skuProps = skuProps == null ? null : skuProps.trim();
    }

    /**
     * 获取用户id
     *
     * @return userId - 用户id
     */
    public Integer getUserId() {
        return userId;
    }

    /**
     * 设置用户id
     *
     * @param userId 用户id
     */
    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    /**
     * 获取购物车商品数量
     *
     * @return cartNum - 购物车商品数量
     */
    public Integer getCartNum() {
        return cartNum;
    }

    /**
     * 设置购物车商品数量
     *
     * @param cartNum 购物车商品数量
     */
    public void setCartNum(Integer cartNum) {
        this.cartNum = cartNum;
    }

    /**
     * 获取添加购物车时间
     *
     * @return cartTime - 添加购物车时间
     */
    public Date getCartTime() {
        return cartTime;
    }

    /**
     * 设置添加购物车时间
     *
     * @param cartTime 添加购物车时间
     */
    public void setCartTime(Date cartTime) {
        this.cartTime = cartTime;
    }

    /**
     * 获取添加购物车的商品价格
     *
     * @return productPrice - 添加购物车的商品价格
     */
    public Integer getProductPrice() {
        return productPrice;
    }

    /**
     * 设置添加购物车的商品价格
     *
     * @param productPrice 添加购物车的商品价格
     */
    public void setProductPrice(Integer productPrice) {
        this.productPrice = productPrice;
    }
}