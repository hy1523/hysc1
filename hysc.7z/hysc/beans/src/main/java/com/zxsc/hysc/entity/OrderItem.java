package com.zxsc.hysc.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

/**
 * 表名：order_item
*/
@Table(name = "order_item")
public class OrderItem {
    @Id
    @Column(name = "item_id")
    private Integer itemId;

    @Column(name = "order_id")
    private Integer orderId;

    public OrderItem(Integer orderId, Integer productId, String productName, String productImg, Integer skuId, String skuName, Integer productPrice, Integer buyCounts, Integer totalAmount, Date basketDate, Date buyTime, Integer isComment) {
        this.orderId = orderId;
        this.productId = productId;
        this.productName = productName;
        this.productImg = productImg;
        this.skuId = skuId;
        this.skuName = skuName;
        this.productPrice = productPrice;
        this.buyCounts = buyCounts;
        this.totalAmount = totalAmount;
        this.basketDate = basketDate;
        this.buyTime = buyTime;
        this.isComment = isComment;
    }

    @Column(name = "product_id")
    private Integer productId;

    @Column(name = "product_name")
    private String productName;

    @Column(name = "product_img")
    private String productImg;

    @Column(name = "sku_id")
    private Integer skuId;

    @Column(name = "sku_name")
    private String skuName;

    @Column(name = "product_price")
    private Integer productPrice;

    @Column(name = "buy_counts")
    private Integer buyCounts;

    @Column(name = "total_amount")
    private Integer totalAmount;

    @Column(name = "basket_date")
    private Date basketDate;

    @Column(name = "buy_time")
    private Date buyTime;

    @Column(name = "is_comment")
    private Integer isComment;

    /**
     * @return itemId
     */
    public Integer getItemId() {
        return itemId;
    }

    /**
     * @param itemId
     */
    public void setItemId(Integer itemId) {
        this.itemId = itemId;
    }

    /**
     * @return orderId
     */
    public Integer getOrderId() {
        return orderId;
    }

    /**
     * @param orderId
     */
    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }

    /**
     * @return productId
     */
    public Integer getProductId() {
        return productId;
    }

    /**
     * @param productId
     */
    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    /**
     * @return productName
     */
    public String getProductName() {
        return productName;
    }

    /**
     * @param productName
     */
    public void setProductName(String productName) {
        this.productName = productName == null ? null : productName.trim();
    }

    /**
     * @return productImg
     */
    public String getProductImg() {
        return productImg;
    }

    /**
     * @param productImg
     */
    public void setProductImg(String productImg) {
        this.productImg = productImg == null ? null : productImg.trim();
    }

    /**
     * @return skuId
     */
    public Integer getSkuId() {
        return skuId;
    }

    /**
     * @param skuId
     */
    public void setSkuId(Integer skuId) {
        this.skuId = skuId;
    }

    /**
     * @return skuName
     */
    public String getSkuName() {
        return skuName;
    }

    /**
     * @param skuName
     */
    public void setSkuName(String skuName) {
        this.skuName = skuName == null ? null : skuName.trim();
    }

    /**
     * @return productPrice
     */
    public Integer getProductPrice() {
        return productPrice;
    }

    /**
     * @param productPrice
     */
    public void setProductPrice(Integer productPrice) {
        this.productPrice = productPrice;
    }

    /**
     * @return buyCounts
     */
    public Integer getBuyCounts() {
        return buyCounts;
    }

    /**
     * @param buyCounts
     */
    public void setBuyCounts(Integer buyCounts) {
        this.buyCounts = buyCounts;
    }

    /**
     * @return totalAmount
     */
    public Integer getTotalAmount() {
        return totalAmount;
    }

    /**
     * @param totalAmount
     */
    public void setTotalAmount(Integer totalAmount) {
        this.totalAmount = totalAmount;
    }

    /**
     * @return basketDate
     */
    public Date getBasketDate() {
        return basketDate;
    }

    /**
     * @param basketDate
     */
    public void setBasketDate(Date basketDate) {
        this.basketDate = basketDate;
    }

    /**
     * @return buyTime
     */
    public Date getBuyTime() {
        return buyTime;
    }

    /**
     * @param buyTime
     */
    public void setBuyTime(Date buyTime) {
        this.buyTime = buyTime;
    }

    /**
     * @return isComment
     */
    public Integer getIsComment() {
        return isComment;
    }

    /**
     * @param isComment
     */
    public void setIsComment(Integer isComment) {
        this.isComment = isComment;
    }
}