package com.zxsc.hysc.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

/**
 * 表名：product_sku
*/
@Table(name = "product_sku")
public class ProductSku {
    @Id
    @Column(name = "sku_id")
    private Integer skuId;

    @Column(name = "pro_id")
    private Integer proId;

    @Column(name = "sku_name")
    private String skuName;

    @Column(name = "sku_img")
    private String skuImg;

    private String untitled;

    @Column(name = "original_price")
    private Integer originalPrice;

    @Column(name = "sell_price")
    private Integer sellPrice;

    private Integer discounts;

    private Integer stock;

    @Column(name = "create_time")
    private Date createTime;

    @Column(name = "update_time")
    private Date updateTime;

    private Integer status;

    /**
     * @return skuId
     */
    public Integer getSkuId() {
        return skuId;
    }

    /**
     * @param skuId
     */
    public void setSkuId(Integer skuId) {
        this.skuId = skuId;
    }

    /**
     * @return proId
     */
    public Integer getProId() {
        return proId;
    }

    /**
     * @param proId
     */
    public void setProId(Integer proId) {
        this.proId = proId;
    }

    /**
     * @return skuName
     */
    public String getSkuName() {
        return skuName;
    }

    /**
     * @param skuName
     */
    public void setSkuName(String skuName) {
        this.skuName = skuName == null ? null : skuName.trim();
    }

    /**
     * @return skuImg
     */
    public String getSkuImg() {
        return skuImg;
    }

    /**
     * @param skuImg
     */
    public void setSkuImg(String skuImg) {
        this.skuImg = skuImg == null ? null : skuImg.trim();
    }

    /**
     * @return untitled
     */
    public String getUntitled() {
        return untitled;
    }

    /**
     * @param untitled
     */
    public void setUntitled(String untitled) {
        this.untitled = untitled == null ? null : untitled.trim();
    }

    /**
     * @return originalPrice
     */
    public Integer getOriginalPrice() {
        return originalPrice;
    }

    /**
     * @param originalPrice
     */
    public void setOriginalPrice(Integer originalPrice) {
        this.originalPrice = originalPrice;
    }

    /**
     * @return sellPrice
     */
    public Integer getSellPrice() {
        return sellPrice;
    }

    /**
     * @param sellPrice
     */
    public void setSellPrice(Integer sellPrice) {
        this.sellPrice = sellPrice;
    }

    /**
     * @return discounts
     */
    public Integer getDiscounts() {
        return discounts;
    }

    /**
     * @param discounts
     */
    public void setDiscounts(Integer discounts) {
        this.discounts = discounts;
    }

    /**
     * @return stock
     */
    public Integer getStock() {
        return stock;
    }

    /**
     * @param stock
     */
    public void setStock(Integer stock) {
        this.stock = stock;
    }

    /**
     * @return createTime
     */
    public Date getCreateTime() {
        return createTime;
    }

    /**
     * @param createTime
     */
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    /**
     * @return updateTime
     */
    public Date getUpdateTime() {
        return updateTime;
    }

    /**
     * @param updateTime
     */
    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    /**
     * @return status
     */
    public Integer getStatus() {
        return status;
    }

    /**
     * @param status
     */
    public void setStatus(Integer status) {
        this.status = status;
    }
}