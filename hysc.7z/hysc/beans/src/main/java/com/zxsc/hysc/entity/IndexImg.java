package com.zxsc.hysc.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

/**
 * 表名：index_img
*/
@Table(name = "index_img")
public class IndexImg {
    @Id
    @Column(name = "img_id")
    private Integer imgId;

    @Column(name = "img_url")
    private String imgUrl;

    @Column(name = "img_bg_color")
    private String imgBgColor;

    @Column(name = "prod_id")
    private Integer prodId;

    @Column(name = "category_id")
    private Integer categoryId;

    @Column(name = "index_type")
    private Integer indexType;

    private Integer seq;

    private Integer status;

    @Column(name = "create_time")
    private Date createTime;

    @Column(name = "update_time")
    private Date updateTime;

    /**
     * @return imgId
     */
    public Integer getImgId() {
        return imgId;
    }

    /**
     * @param imgId
     */
    public void setImgId(Integer imgId) {
        this.imgId = imgId;
    }

    /**
     * @return imgUrl
     */
    public String getImgUrl() {
        return imgUrl;
    }

    /**
     * @param imgUrl
     */
    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl == null ? null : imgUrl.trim();
    }

    /**
     * @return imgBgColor
     */
    public String getImgBgColor() {
        return imgBgColor;
    }

    /**
     * @param imgBgColor
     */
    public void setImgBgColor(String imgBgColor) {
        this.imgBgColor = imgBgColor == null ? null : imgBgColor.trim();
    }

    /**
     * @return prodId
     */
    public Integer getProdId() {
        return prodId;
    }

    /**
     * @param prodId
     */
    public void setProdId(Integer prodId) {
        this.prodId = prodId;
    }

    /**
     * @return categoryId
     */
    public Integer getCategoryId() {
        return categoryId;
    }

    /**
     * @param categoryId
     */
    public void setCategoryId(Integer categoryId) {
        this.categoryId = categoryId;
    }

    /**
     * @return indexType
     */
    public Integer getIndexType() {
        return indexType;
    }

    /**
     * @param indexType
     */
    public void setIndexType(Integer indexType) {
        this.indexType = indexType;
    }

    /**
     * @return seq
     */
    public Integer getSeq() {
        return seq;
    }

    /**
     * @param seq
     */
    public void setSeq(Integer seq) {
        this.seq = seq;
    }

    /**
     * @return status
     */
    public Integer getStatus() {
        return status;
    }

    /**
     * @param status
     */
    public void setStatus(Integer status) {
        this.status = status;
    }

    /**
     * @return createTime
     */
    public Date getCreateTime() {
        return createTime;
    }

    /**
     * @param createTime
     */
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    /**
     * @return updateTime
     */
    public Date getUpdateTime() {
        return updateTime;
    }

    /**
     * @param updateTime
     */
    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }
}