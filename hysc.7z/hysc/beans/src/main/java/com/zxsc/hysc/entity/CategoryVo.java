package com.zxsc.hysc.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.util.List;

/**
 * 表名：category
*/
public class CategoryVo {
    @Id
    @Column(name = "category_id")
    private Integer categoryId;

    @Column(name = "category_name")
    private String categoryName;

    private Integer calevel;

    @Column(name = "parent_id")
    private Integer parentId;

    @Column(name = "category_icon")
    private String categoryIcon;

    @Column(name = "category_slogan")
    private String categorySlogan;

    @Column(name = "category_pic")
    private String categoryPic;

    @Column(name = "category_bg_color")
    private String categoryBgColor;

    private List<CategoryVo> categoryList;

    public List<CategoryVo> getCategoryList() {
        return categoryList;
    }

    public void setCategoryList(List<CategoryVo> categoryList) {
        this.categoryList = categoryList;
    }

    /**
     * @return categoryId
     */
    public Integer getCategoryId() {
        return categoryId;
    }

    /**
     * @param categoryId
     */
    public void setCategoryId(Integer categoryId) {
        this.categoryId = categoryId;
    }

    /**
     * @return categoryName
     */
    public String getCategoryName() {
        return categoryName;
    }

    /**
     * @param categoryName
     */
    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName == null ? null : categoryName.trim();
    }

    /**
     * @return calevel
     */
    public Integer getCalevel() {
        return calevel;
    }

    /**
     * @param calevel
     */
    public void setCalevel(Integer calevel) {
        this.calevel = calevel;
    }

    /**
     * @return parentId
     */
    public Integer getParentId() {
        return parentId;
    }

    /**
     * @param parentId
     */
    public void setParentId(Integer parentId) {
        this.parentId = parentId;
    }

    /**
     * @return categoryIcon
     */
    public String getCategoryIcon() {
        return categoryIcon;
    }

    /**
     * @param categoryIcon
     */
    public void setCategoryIcon(String categoryIcon) {
        this.categoryIcon = categoryIcon == null ? null : categoryIcon.trim();
    }

    /**
     * @return categorySlogan
     */
    public String getCategorySlogan() {
        return categorySlogan;
    }

    /**
     * @param categorySlogan
     */
    public void setCategorySlogan(String categorySlogan) {
        this.categorySlogan = categorySlogan == null ? null : categorySlogan.trim();
    }

    /**
     * @return categoryPic
     */
    public String getCategoryPic() {
        return categoryPic;
    }

    /**
     * @param categoryPic
     */
    public void setCategoryPic(String categoryPic) {
        this.categoryPic = categoryPic == null ? null : categoryPic.trim();
    }

    /**
     * @return categoryBgColor
     */
    public String getCategoryBgColor() {
        return categoryBgColor;
    }

    /**
     * @param categoryBgColor
     */
    public void setCategoryBgColor(String categoryBgColor) {
        this.categoryBgColor = categoryBgColor == null ? null : categoryBgColor.trim();
    }
}