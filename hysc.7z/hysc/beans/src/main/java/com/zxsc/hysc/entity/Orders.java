package com.zxsc.hysc.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.util.Date;

/**
 * 表名：orders
*/
public class Orders {
    @Id
    @Column(name = "order_id")
    private Integer orderId;

    @Column(name = "user_id")
    private Integer userId;

    private String untitled;

    @Column(name = "receiver_name")
    private String receiverName;

    @Column(name = "receiver_mobile")
    private String receiverMobile;

    @Column(name = "receiver_address")
    private String receiverAddress;

    @Column(name = "totel_amount")
    private Integer totelAmount;

    @Column(name = "actual_amount")
    private Integer actualAmount;

    @Column(name = "pay_type")
    private Integer payType;

    @Column(name = "order_remark")
    private String orderRemark;

    private String status;

    @Column(name = "delivery_flow_id")
    private Integer deliveryFlowId;

    @Column(name = "order_feright")
    private Integer orderFeright;

    @Column(name = "delete_status")
    private Integer deleteStatus;

    @Column(name = "create_time")
    private Date createTime;

    @Column(name = "update_time")
    private Date updateTime;

    @Column(name = "pay_time")
    private Date payTime;

    @Column(name = "delivery_time")
    private Date deliveryTime;

    @Column(name = "flish_time")
    private Date flishTime;

    @Column(name = "cancel_time")
    private Date cancelTime;

    @Column(name = "close_type")
    private Integer closeType;

    /**
     * @return orderId
     */
    public Integer getOrderId() {
        return orderId;
    }

    /**
     * @param orderId
     */
    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }

    /**
     * @return userId
     */
    public Integer getUserId() {
        return userId;
    }

    /**
     * @param userId
     */
    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    /**
     * @return untitled
     */
    public String getUntitled() {
        return untitled;
    }

    /**
     * @param untitled
     */
    public void setUntitled(String untitled) {
        this.untitled = untitled == null ? null : untitled.trim();
    }

    /**
     * @return receiverName
     */
    public String getReceiverName() {
        return receiverName;
    }

    /**
     * @param receiverName
     */
    public void setReceiverName(String receiverName) {
        this.receiverName = receiverName == null ? null : receiverName.trim();
    }

    /**
     * @return receiverMobile
     */
    public String getReceiverMobile() {
        return receiverMobile;
    }

    /**
     * @param receiverMobile
     */
    public void setReceiverMobile(String receiverMobile) {
        this.receiverMobile = receiverMobile == null ? null : receiverMobile.trim();
    }

    /**
     * @return receiverAddress
     */
    public String getReceiverAddress() {
        return receiverAddress;
    }

    /**
     * @param receiverAddress
     */
    public void setReceiverAddress(String receiverAddress) {
        this.receiverAddress = receiverAddress == null ? null : receiverAddress.trim();
    }

    /**
     * @return totelAmount
     */
    public Integer getTotelAmount() {
        return totelAmount;
    }

    /**
     * @param totelAmount
     */
    public void setTotelAmount(Integer totelAmount) {
        this.totelAmount = totelAmount;
    }

    /**
     * @return actualAmount
     */
    public Integer getActualAmount() {
        return actualAmount;
    }

    /**
     * @param actualAmount
     */
    public void setActualAmount(Integer actualAmount) {
        this.actualAmount = actualAmount;
    }

    /**
     * @return payType
     */
    public Integer getPayType() {
        return payType;
    }

    /**
     * @param payType
     */
    public void setPayType(Integer payType) {
        this.payType = payType;
    }

    /**
     * @return orderRemark
     */
    public String getOrderRemark() {
        return orderRemark;
    }

    /**
     * @param orderRemark
     */
    public void setOrderRemark(String orderRemark) {
        this.orderRemark = orderRemark == null ? null : orderRemark.trim();
    }

    /**
     * @return status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @param status
     */
    public void setStatus(String status) {
        this.status = status == null ? null : status.trim();
    }

    /**
     * @return deliveryFlowId
     */
    public Integer getDeliveryFlowId() {
        return deliveryFlowId;
    }

    /**
     * @param deliveryFlowId
     */
    public void setDeliveryFlowId(Integer deliveryFlowId) {
        this.deliveryFlowId = deliveryFlowId;
    }

    /**
     * @return orderFeright
     */
    public Integer getOrderFeright() {
        return orderFeright;
    }

    /**
     * @param orderFeright
     */
    public void setOrderFeright(Integer orderFeright) {
        this.orderFeright = orderFeright;
    }

    /**
     * @return deleteStatus
     */
    public Integer getDeleteStatus() {
        return deleteStatus;
    }

    /**
     * @param deleteStatus
     */
    public void setDeleteStatus(Integer deleteStatus) {
        this.deleteStatus = deleteStatus;
    }

    /**
     * @return createTime
     */
    public Date getCreateTime() {
        return createTime;
    }

    /**
     * @param createTime
     */
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    /**
     * @return updateTime
     */
    public Date getUpdateTime() {
        return updateTime;
    }

    /**
     * @param updateTime
     */
    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    /**
     * @return payTime
     */
    public Date getPayTime() {
        return payTime;
    }

    /**
     * @param payTime
     */
    public void setPayTime(Date payTime) {
        this.payTime = payTime;
    }

    /**
     * @return deliveryTime
     */
    public Date getDeliveryTime() {
        return deliveryTime;
    }

    /**
     * @param deliveryTime
     */
    public void setDeliveryTime(Date deliveryTime) {
        this.deliveryTime = deliveryTime;
    }

    /**
     * @return flishTime
     */
    public Date getFlishTime() {
        return flishTime;
    }

    /**
     * @param flishTime
     */
    public void setFlishTime(Date flishTime) {
        this.flishTime = flishTime;
    }

    /**
     * @return cancelTime
     */
    public Date getCancelTime() {
        return cancelTime;
    }

    /**
     * @param cancelTime
     */
    public void setCancelTime(Date cancelTime) {
        this.cancelTime = cancelTime;
    }

    /**
     * @return closeType
     */
    public Integer getCloseType() {
        return closeType;
    }

    /**
     * @param closeType
     */
    public void setCloseType(Integer closeType) {
        this.closeType = closeType;
    }
}