package com.zxsc.hysc.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

/**
 * 表名：product_comments
*/
@Table(name = "product_comments")
public class ProductComments {
    @Id
    @Column(name = "comm_id")
    private Integer commId;

    @Column(name = "product_id")
    private Integer productId;

    @Column(name = "product_name")
    private String productName;

    @Column(name = "orderitem_id")
    private Integer orderitemId;

    @Column(name = "user_id")
    private Integer userId;

    @Column(name = "is_anonymous")
    private Integer isAnonymous;

    @Column(name = "comm_type")
    private Integer commType;

    @Column(name = "comm_level")
    private Integer commLevel;

    @Column(name = "comm_imgs")
    private String commImgs;

    @Column(name = "sepc_name")
    private String sepcName;

    @Column(name = "reply_status")
    private Integer replyStatus;

    @Column(name = "reply_content")
    private String replyContent;

    @Column(name = "reply_time")
    private Date replyTime;

    @Column(name = "is_show")
    private Integer isShow;

    @Column(name = "comm_content")
    private String commContent;

    /**
     * @return commId
     */
    public Integer getCommId() {
        return commId;
    }

    /**
     * @param commId
     */
    public void setCommId(Integer commId) {
        this.commId = commId;
    }

    /**
     * @return productId
     */
    public Integer getProductId() {
        return productId;
    }

    /**
     * @param productId
     */
    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    /**
     * @return productName
     */
    public String getProductName() {
        return productName;
    }

    /**
     * @param productName
     */
    public void setProductName(String productName) {
        this.productName = productName == null ? null : productName.trim();
    }

    /**
     * @return orderitemId
     */
    public Integer getOrderitemId() {
        return orderitemId;
    }

    /**
     * @param orderitemId
     */
    public void setOrderitemId(Integer orderitemId) {
        this.orderitemId = orderitemId;
    }

    /**
     * @return userId
     */
    public Integer getUserId() {
        return userId;
    }

    /**
     * @param userId
     */
    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    /**
     * @return isAnonymous
     */
    public Integer getIsAnonymous() {
        return isAnonymous;
    }

    /**
     * @param isAnonymous
     */
    public void setIsAnonymous(Integer isAnonymous) {
        this.isAnonymous = isAnonymous;
    }

    /**
     * @return commType
     */
    public Integer getCommType() {
        return commType;
    }

    /**
     * @param commType
     */
    public void setCommType(Integer commType) {
        this.commType = commType;
    }

    /**
     * @return commLevel
     */
    public Integer getCommLevel() {
        return commLevel;
    }

    /**
     * @param commLevel
     */
    public void setCommLevel(Integer commLevel) {
        this.commLevel = commLevel;
    }

    /**
     * @return commImgs
     */
    public String getCommImgs() {
        return commImgs;
    }

    /**
     * @param commImgs
     */
    public void setCommImgs(String commImgs) {
        this.commImgs = commImgs == null ? null : commImgs.trim();
    }

    /**
     * @return sepcName
     */
    public String getSepcName() {
        return sepcName;
    }

    /**
     * @param sepcName
     */
    public void setSepcName(String sepcName) {
        this.sepcName = sepcName == null ? null : sepcName.trim();
    }

    /**
     * @return replyStatus
     */
    public Integer getReplyStatus() {
        return replyStatus;
    }

    /**
     * @param replyStatus
     */
    public void setReplyStatus(Integer replyStatus) {
        this.replyStatus = replyStatus;
    }

    /**
     * @return replyContent
     */
    public String getReplyContent() {
        return replyContent;
    }

    /**
     * @param replyContent
     */
    public void setReplyContent(String replyContent) {
        this.replyContent = replyContent == null ? null : replyContent.trim();
    }

    /**
     * @return replyTime
     */
    public Date getReplyTime() {
        return replyTime;
    }

    /**
     * @param replyTime
     */
    public void setReplyTime(Date replyTime) {
        this.replyTime = replyTime;
    }

    /**
     * @return isShow
     */
    public Integer getIsShow() {
        return isShow;
    }

    /**
     * @param isShow
     */
    public void setIsShow(Integer isShow) {
        this.isShow = isShow;
    }

    /**
     * @return commContent
     */
    public String getCommContent() {
        return commContent;
    }

    /**
     * @param commContent
     */
    public void setCommContent(String commContent) {
        this.commContent = commContent == null ? null : commContent.trim();
    }
}