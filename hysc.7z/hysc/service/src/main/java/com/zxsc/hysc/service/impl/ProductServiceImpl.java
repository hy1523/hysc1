package com.zxsc.hysc.service.impl;

import com.zxsc.hysc.dao.ProductImgMapper;
import com.zxsc.hysc.dao.ProductMapper;
import com.zxsc.hysc.dao.ProductParamsMapper;
import com.zxsc.hysc.dao.ProductSkuMapper;
import com.zxsc.hysc.entity.*;
import com.zxsc.hysc.service.ProductService;
import com.zxsc.hysc.vo.ResStatus;
import com.zxsc.hysc.vo.ResultVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import tk.mybatis.mapper.entity.Example;

import java.util.HashMap;
import java.util.List;


@Service
public class ProductServiceImpl implements ProductService {

    @Autowired
    private ProductMapper productMapper;

    @Autowired
    private ProductImgMapper productImgMapper;

    @Autowired
    private ProductSkuMapper productSkuMapper;

    @Autowired
    private ProductParamsMapper productParamsMapper;

    public ResultVO SelectProduct(){
        List<ProductVO> productVOS=productMapper.SelectProductList();
        ResultVO resultVO=new ResultVO(ResStatus.OK,"成功",productVOS);
        return resultVO;
    }

    public ResultVO SelectAllProduct(){
        List<ProductVO> productVOS=productMapper.SelectAllProductList();
        ResultVO resultVO=new ResultVO(ResStatus.OK,"成功",productVOS);
        return resultVO;
    }

    @Transactional(propagation = Propagation.SUPPORTS)
    public ResultVO getProductInfo(int productId){
        //商品基本信息
        Example example = new Example(Product.class);
        Example.Criteria criteria=example.createCriteria();
        criteria.andEqualTo("productId",productId);
        criteria.andEqualTo("productStatus",1);//状态为1

        List<Product> products=productMapper.selectByExample(example);
        if(products.size()>0){
            //商品图片
            Example example1 = new Example(ProductImg.class);
            Example.Criteria criteria1=example1.createCriteria();
            criteria1.andEqualTo("itemId",productId);
            List<ProductImg> productImgs = productImgMapper.selectByExample(example1);
            //商品套餐
            Example example2 = new Example(ProductSku.class);
            Example.Criteria criteria2=example2.createCriteria();
            criteria2.andEqualTo("proId",productId);
            criteria2.andEqualTo("status",1);
            List<ProductSku> productSkus=productSkuMapper.selectByExample(example2);

            HashMap<String,Object> basicInfo=new HashMap<>();
            basicInfo.put("product",products.get(0));
            basicInfo.put("productImgs",productImgs);
            basicInfo.put("productSkus",productSkus);
            return new ResultVO(ResStatus.OK,"成功",basicInfo);
        }else {
            return new ResultVO(ResStatus.NO,"查询的商品不存在",null);
        }
    }

    @Override
    public ResultVO getProductParamsById(int productId){
        Example example = new Example(ProductParams.class);
        Example.Criteria criteria=example.createCriteria();
        criteria.andEqualTo("productId",productId);
        List<ProductParams> productParams=productParamsMapper.selectByExample(example);
        if(productParams.size()>0){
            return new ResultVO(ResStatus.OK,"成功",productParams.get(0));
        }
        else {
            return new ResultVO(ResStatus.NO,"失败",null);
        }


    }
    @Override
    public ResultVO getProductIdByName(String categoryName){
        int i=productMapper.SelectProductIdByName(categoryName);
        ResultVO resultVO=new ResultVO(ResStatus.OK,"成功",i);
        return resultVO;
    }
}
