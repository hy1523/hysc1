package com.zxsc.hysc.service.impl;

import com.zxsc.hysc.dao.CategoryMapper;
import com.zxsc.hysc.entity.CategoryVo;
import com.zxsc.hysc.service.CategoryService;
import com.zxsc.hysc.vo.ResStatus;
import com.zxsc.hysc.vo.ResultVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CayegoryServiceImpl implements CategoryService {

    @Autowired
    private CategoryMapper categoryMapper;


    public ResultVO listCategories(){
        List<CategoryVo> categoryVos=categoryMapper.selectCategoryList();
        ResultVO resultVO=new ResultVO(ResStatus.OK,"success",categoryVos);
        return resultVO;
    }
}
