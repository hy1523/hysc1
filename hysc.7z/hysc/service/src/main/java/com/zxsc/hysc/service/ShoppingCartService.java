package com.zxsc.hysc.service;

import com.zxsc.hysc.entity.ShoppingCart;
import com.zxsc.hysc.vo.ResultVO;

import java.util.List;

public interface ShoppingCartService {
    public ResultVO addShoppingCart(ShoppingCart cart);

    public ResultVO listShoppingCartByUserId(int userId);

    public ResultVO updateCartNum(int cartId,int cartNum);

    public ResultVO delectCart(int cartId);

    public ResultVO listShoppingCartCids(String cids);
}
