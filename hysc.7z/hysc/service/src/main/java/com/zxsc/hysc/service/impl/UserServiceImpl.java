package com.zxsc.hysc.service.impl;

import com.zxsc.hysc.dao.AdMapper;
import com.zxsc.hysc.dao.UserscMapper;
import com.zxsc.hysc.entity.Aduser;
import com.zxsc.hysc.entity.Usersc;
import com.zxsc.hysc.service.UserService;
import com.zxsc.hysc.utils.MD5UTILS;
import com.zxsc.hysc.vo.ResStatus;
import com.zxsc.hysc.vo.ResultVO;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.JwtBuilder;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.apache.catalina.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import tk.mybatis.mapper.entity.Example;

import java.util.Date;
import java.util.HashMap;
import java.util.List;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserscMapper userscMapper;

    @Autowired
    private AdMapper adMapper;



    @Transactional
    @Scope("singleton")
    public ResultVO userResgit(String username,String password){
        synchronized (this) {
            //1用户是否被注册
            Example example=new Example(Usersc.class);
            Example.Criteria criteria=example.createCriteria();
            criteria.andEqualTo("username",username);
            List<Usersc> users= userscMapper.selectByExample(example);


            //如果没有注册,则保持
            if (users.size()==0) {
                String md5Pwd = MD5UTILS.md5(password);
                Usersc user = new Usersc();
                user.setUsername(username);
                user.setPassword(md5Pwd);
                user.setUserRegtime(new Date());
                user.setUserModtime(new Date());
                int i = userscMapper.insert(user);
                if (i > 0) {
                    return new ResultVO(ResStatus.OK, "注册成功", null);
                } else {
                    return new ResultVO(ResStatus.NO, "注册失败", null);
                }
            } else {
                return new ResultVO(ResStatus.NO, "用户被注册", null);
            }
        }
    }


    @Override
    public ResultVO checkLogin(String username,String password){
        Example example=new Example(Usersc.class);
        Example.Criteria criteria=example.createCriteria();
        criteria.andEqualTo("username",username);
        List<Usersc> users=userscMapper.selectByExample(example);
        if(users.size()==0){
            return new ResultVO(ResStatus.NO,"登录失败,用户名不存在",null);
        }else {
            String md5Pwd=MD5UTILS.md5(password);

            if(md5Pwd.equals(users.get(0).getPassword())){
                //如果登录验证成功，生成token(特定规律生成的字符串)
                //使用JWT规则生成token
                JwtBuilder builder=Jwts.builder();

                HashMap<String,Object> map=new HashMap<>();


                String token = builder.setSubject(username) //主题，token中携带的数据
                        .setIssuedAt(new Date()) //设置token的生成时间
                        .setId(users.get(0).getUserId() + "") //设置用户id为token id
                        .setClaims(map)        //map中可以存放用户的角色权限信息
                        .setExpiration(new Date(System.currentTimeMillis() + 24 * 60 * 60 * 1000))  //设置token的过期时间
                        .signWith(SignatureAlgorithm.HS256, "hy123456")//设置加密方式和加密的密码
                        .compact();

                return new ResultVO(ResStatus.OK,token,users.get(0));
            }else {
                return new ResultVO(ResStatus.NO,"登陆失败,密码错误",null);
            }
        }
    }
//    @Override
//    public ResultVO checkLogin(Aduser form){
//        System.out.println(form);
//        System.out.println(form.getUsername());
//        Aduser user=adMapper.selectByname(form.getUsername());
//        System.out.println(user);
//        if(user==null){
//            return new ResultVO(10001,"登录失败,用户名不存在",null);
//        }else {
//           // String md5Pwd=MD5UTILS.md5(loginForm.getPassword());
//            if(form.getPassword().equals(user.getPassword())){
//                return new ResultVO(10000,"登陆成功",user);
//            }else {
//                return new ResultVO(10001,"登陆失败,密码错误",null);
//            }
//        }


    public ResultVO selectUserByUserId(int userId){
        Example example = new Example(Usersc.class);
        Example.Criteria criteria=example.createCriteria();
        criteria.andEqualTo("userId",userId);

        Usersc usersc=userscMapper.selectOneByExample(example);
        return new ResultVO(ResStatus.OK,"成功",usersc);
    }
    }


