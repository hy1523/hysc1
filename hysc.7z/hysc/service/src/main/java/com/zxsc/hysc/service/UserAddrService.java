package com.zxsc.hysc.service;

import com.zxsc.hysc.vo.ResultVO;

public interface UserAddrService {
    public ResultVO listAddrsByUid(int userId);
}
