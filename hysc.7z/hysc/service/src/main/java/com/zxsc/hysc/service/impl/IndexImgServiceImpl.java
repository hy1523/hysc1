package com.zxsc.hysc.service.impl;

import com.zxsc.hysc.dao.IndexImgMapper;
import com.zxsc.hysc.entity.IndexImg;
import com.zxsc.hysc.service.IndexImgService;
import com.zxsc.hysc.vo.ResStatus;
import com.zxsc.hysc.vo.ResultVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class IndexImgServiceImpl implements IndexImgService {

    @Autowired
    private IndexImgMapper indexImgMapper;

    @Override
    public ResultVO listIndexImg(){
        List<IndexImg> indexImgs=indexImgMapper.listIndexImg();
        if(indexImgs.size()==0){
            return new ResultVO(ResStatus.NO,"获取失败",null);
        }
        else {
            return new ResultVO(ResStatus.OK,"成功",indexImgs);
        }
    }
}
