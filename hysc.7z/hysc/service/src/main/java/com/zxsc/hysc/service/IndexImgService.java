package com.zxsc.hysc.service;

import com.zxsc.hysc.vo.ResultVO;



public interface IndexImgService {
    public ResultVO listIndexImg();
}
