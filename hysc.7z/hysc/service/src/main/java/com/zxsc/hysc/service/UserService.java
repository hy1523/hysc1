package com.zxsc.hysc.service;

import com.zxsc.hysc.entity.Aduser;
import com.zxsc.hysc.vo.ResultVO;

public interface UserService {
    public ResultVO checkLogin(String username, String password);

//    public ResultVO checkLogin(Aduser form);

    public ResultVO userResgit(String username,String password);

    public ResultVO selectUserByUserId(int userId);

}
