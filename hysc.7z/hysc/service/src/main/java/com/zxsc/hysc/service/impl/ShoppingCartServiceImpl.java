package com.zxsc.hysc.service.impl;

import com.zxsc.hysc.dao.ShoppingCartMapper;
import com.zxsc.hysc.entity.ProductParams;
import com.zxsc.hysc.entity.ShoppingCart;
import com.zxsc.hysc.entity.ShoppingCartVO;
import com.zxsc.hysc.service.ShoppingCartService;
import com.zxsc.hysc.vo.ResStatus;
import com.zxsc.hysc.vo.ResultVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import tk.mybatis.mapper.entity.Example;

import java.text.SimpleDateFormat;
import java.util.*;

@Service
public class ShoppingCartServiceImpl implements ShoppingCartService {
    @Autowired
    private ShoppingCartMapper shoppingCartMapper;
    private SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");

    @Override
    public ResultVO addShoppingCart(ShoppingCart cart){
        cart.setCartTime(new Date());
        int i=shoppingCartMapper.insert(cart);
        if(i>0){
            return new ResultVO(ResStatus.OK,"成功",null);
        }
        else {
            return new ResultVO(ResStatus.NO,"失败",null);
        }
    }

    @Override
    public ResultVO listShoppingCartByUserId(int userId){
        List<ShoppingCartVO> list=shoppingCartMapper.selectShopcartByUserId(userId);
        return new ResultVO(ResStatus.OK,"成功",list);
    }

    @Override
    public ResultVO updateCartNum(int cartId,int cartNum){
        int i = shoppingCartMapper.updateCartNumByCartId(cartId, cartNum);
        if(i>0) {
            return new ResultVO(ResStatus.OK,"成功",null);
        }else {
            return new ResultVO(ResStatus.NO,"失败",null);
        }
    }

    @Override
    public ResultVO delectCart(int cartId){
        Example example = new Example(ShoppingCart.class);
        Example.Criteria criteria=example.createCriteria();
        criteria.andEqualTo("cartId",cartId);
        shoppingCartMapper.deleteByExample(example);
        return new ResultVO(ResStatus.OK,"成功",null);
    }

    @Override
    public ResultVO listShoppingCartCids(String cids){
        String[] arr = cids.split(",");

        List<Integer> cartIds=new ArrayList<>();
        for(int i=0;i<arr.length;i++){
            cartIds.add(Integer.parseInt(arr[i]));
        }

        List<ShoppingCartVO> list=shoppingCartMapper.selectShoppingByCids(cartIds);
        ResultVO resultVO = new ResultVO(ResStatus.OK, "成功", list);
        return resultVO;
    }
}
