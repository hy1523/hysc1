package com.zxsc.hysc.service;

import com.zxsc.hysc.vo.ResultVO;

public interface ProductCommentsService {

    public ResultVO listCommentsByProductId(int productId,int pageNum,int limit);

    //通过商品id统计评论数量
    public ResultVO getCommentCountByProductId(int productId);
}
