package com.zxsc.hysc.service.impl;

import com.zxsc.hysc.dao.ProductCommentsMapper;
import com.zxsc.hysc.entity.ProductComments;
import com.zxsc.hysc.entity.ProductCommentsVo;
import com.zxsc.hysc.service.ProductCommentsService;
import com.zxsc.hysc.utils.PageHelper;
import com.zxsc.hysc.vo.ResStatus;
import com.zxsc.hysc.vo.ResultVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import tk.mybatis.mapper.entity.Example;

import java.util.HashMap;
import java.util.List;

@Service
public class ProductCommentsServiceImpl implements ProductCommentsService {

    @Autowired
    private ProductCommentsMapper productCommentsMapper;

    @Override
    public ResultVO listCommentsByProductId(int productId,int pageNum,int limit){
//        List<ProductCommentsVo> productCommentsVos=productCommentsMapper.selectCommentsByProductId(productId);

        //1根据商品id查询总记录数
        Example example=new Example(ProductComments.class);
        Example.Criteria criteria=example.createCriteria();
        criteria.andEqualTo("productId",productId);
        int count= productCommentsMapper.selectCountByExample(example);


        //2，计算总页数(必须知道每页显示多少条 pageSize=limit)
        int pageCount=count%limit==0? count/limit : count/limit+1;

        //3,查询当前页的数据(评论中有用户信息，所以连表查询)
        int start=(pageNum-1)*limit;
        List<ProductCommentsVo> productCommentsVos = productCommentsMapper.selectCommentsByProductId(productId, start, limit);




        ResultVO resultVO = new ResultVO(ResStatus.OK,"成功",new PageHelper<ProductCommentsVo>(count,pageCount,productCommentsVos));
        return resultVO;
    }

    @Override
    public ResultVO getCommentCountByProductId(int productId){
        //1查询评论数量
        Example example=new Example(ProductComments.class);
        Example.Criteria criteria=example.createCriteria();
        criteria.andEqualTo("productId",productId);

        int total=productCommentsMapper.selectCountByExample(example);

        //2查询好评数量
        Example example1=new Example(ProductComments.class);
        Example.Criteria criteria1=example1.createCriteria();
        criteria1.andEqualTo("productId",productId);
        criteria1.andEqualTo("commType",1);
        int goodTotal=productCommentsMapper.selectCountByExample(example1);

        //3查询中评数量
        Example example2=new Example(ProductComments.class);
        Example.Criteria criteria2=example2.createCriteria();
        criteria2.andEqualTo("productId",productId);
        criteria2.andEqualTo("commType",0);
        int midTotal=productCommentsMapper.selectCountByExample(example2);

        //4查询差评数量
        Example example3=new Example(ProductComments.class);
        Example.Criteria criteria3=example3.createCriteria();
        criteria3.andEqualTo("productId",productId);
        criteria3.andEqualTo("commType",-1);
        int badTotal=productCommentsMapper.selectCountByExample(example3);

        //5,计算好评率
        double percent=(Double.parseDouble(goodTotal+"")/Double.parseDouble(total+""))*100;
        String percentValue=(percent+"").substring(0,(percent+"").lastIndexOf(".")+3);


        HashMap<String,Object> map=new HashMap<>();
        map.put("total",total);
        map.put("goodTotal",goodTotal);
        map.put("midTotal",midTotal);
        map.put("badTotal",badTotal);
        map.put("percent",percentValue);

        ResultVO resultVO=new ResultVO(ResStatus.OK,"成功",map);
        return resultVO;
    }
}
