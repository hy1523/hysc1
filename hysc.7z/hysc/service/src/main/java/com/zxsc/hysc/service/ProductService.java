package com.zxsc.hysc.service;

import com.zxsc.hysc.vo.ResultVO;

public interface ProductService {
    public ResultVO SelectProduct();

    public ResultVO SelectAllProduct();

    public ResultVO getProductInfo(int productId);

    public ResultVO getProductParamsById(int productId);

    public ResultVO getProductIdByName(String categoryName);
}
