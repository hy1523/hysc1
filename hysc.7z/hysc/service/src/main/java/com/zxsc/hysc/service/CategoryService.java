package com.zxsc.hysc.service;


import com.zxsc.hysc.vo.ResultVO;

public interface CategoryService {

    public ResultVO listCategories();
}
