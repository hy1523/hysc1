package com.zxsc.hysc.service;

import com.zxsc.hysc.entity.Orders;
import com.zxsc.hysc.vo.ResultVO;

public interface OrderService {

    public ResultVO addOrder(String cids, Orders orders);

    public ResultVO getOrderByUserIdAndStatus(int userId,int status);
}
