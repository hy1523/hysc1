package com.zxsc.hysc.service.impl;

import com.zxsc.hysc.dao.OrderItemMapper;
import com.zxsc.hysc.dao.OrdersMapper;
import com.zxsc.hysc.dao.ProductSkuMapper;
import com.zxsc.hysc.dao.ShoppingCartMapper;
import com.zxsc.hysc.entity.OrderItem;
import com.zxsc.hysc.entity.Orders;
import com.zxsc.hysc.entity.ProductSku;
import com.zxsc.hysc.entity.ShoppingCartVO;
import com.zxsc.hysc.service.OrderService;
import com.zxsc.hysc.vo.ResStatus;
import com.zxsc.hysc.vo.ResultVO;
import io.swagger.models.auth.In;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import tk.mybatis.mapper.entity.Example;

import java.util.*;

@Service
public class OrderServiceImpl implements OrderService {

    @Autowired
    private ShoppingCartMapper shoppingCartMapper;
    @Autowired
    private OrdersMapper ordersMapper;
    @Autowired
    private OrderItemMapper orderItemMapper;
    @Autowired
    private ProductSkuMapper productSkuMapper;

    @Override
    @Transactional
    public ResultVO addOrder(String cids,Orders orders){
        //1，根据cids查询当前订单中的购物车
        String[] split = cids.split(",");
        List<Integer> cidsList=new ArrayList<>();
        for(int i=0;i<split.length;i++){
            cidsList.add(Integer.parseInt(split[i]));
        }
        List<ShoppingCartVO> list=shoppingCartMapper.selectShoppingByCids(cidsList);

        //2，校验库存
        boolean f=true;
        String untitled="";
        for(ShoppingCartVO sc:list){
            if(sc.getCartNum()>sc.getSkuStock()){
                f=false;
            }
            //获取所有商品的名称，已，隔开，拼接成字符串
            untitled=untitled+sc.getProductName()+",";
        }


        if(f){
            //表示库存充足----保存订单
            //userId,
            // untitled,
            // 收货人信息:姓名，电话，地址
            //总价格
            //支付方式
            //订单创建时间
            //订单初始状态（待支付:1）
            //订单Id
            orders.setUntitled(untitled);
            orders.setCreateTime(new Date());
            orders.setStatus("1");

            //3，生成订单编号
            //String orderIds = UUID.randomUUID().toString().replace("-", "");
            //Integer orderId=(Integer.parseInt(orderIds));


            Random rand = new Random();
            int orderId = rand.nextInt(999);
            orders.setOrderId(orderId);

            //保存订单
            int i = ordersMapper.insert(orders);

            //4，生成商品快照
            List<OrderItem> orderItems=new ArrayList<>();
            for(ShoppingCartVO sc:list){
//                String itemIds=System.currentTimeMillis()+""+(new Random().nextInt(8999)+1000);
//                int itemId=(Integer.parseInt(itemIds));
                OrderItem orderItem = new OrderItem(orderId,sc.getProductId(), sc.getProductName(), sc.getProductImg(), sc.getSkuId(),
                        sc.getSkuName(), sc.getProductPrice(), sc.getCartNum(), sc.getCartNum() * sc.getProductPrice(), new Date(), new Date(), 0);
                orderItems.add(orderItem);
            }
            int j = orderItemMapper.insertList(orderItems);

            //5，扣减库存
            for(ShoppingCartVO sc:list){
                int skuId=sc.getSkuId();
                int newStock=sc.getSkuStock()-sc.getCartNum();

                Example example = new Example(ProductSku.class);
                Example.Criteria criteria =example.createCriteria();
                criteria.andEqualTo("skuId",skuId);

                ProductSku productSku=productSkuMapper.selectByPrimaryKey(skuId);
                productSku.setStock(newStock);
                int k = productSkuMapper.updateByExample(productSku, example);

//                ProductSku productSku=new ProductSku();
//                productSku.setSkuId(skuId);
//                productSku.setStock(newStock);
//                int k = productSkuMapper.updateByPrimaryKey(productSku);

            }
            //删除购物车，当购买成功后，删除记录
            for (int cid:cidsList){
                shoppingCartMapper.deleteByPrimaryKey(cid);
            }


            return new ResultVO(ResStatus.OK,"下单成功",null );
        }else {
            //表示库存不足
            return new ResultVO(ResStatus.NO,"库存不足，下单失败",null);
        }
    }

    public ResultVO getOrderByUserIdAndStatus(int userId,int status){
        List<Orders> list=ordersMapper.selectOrderListByUserIdAndStatus(userId, status);
        ResultVO resultVO=new ResultVO(ResStatus.OK,"成功",list);
        return resultVO;
    }
}
