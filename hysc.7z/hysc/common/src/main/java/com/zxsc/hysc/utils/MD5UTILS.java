package com.zxsc.hysc.utils;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class MD5UTILS {
    public static String md5(String password){
        //生成一个MD5加密器
        try{
            MessageDigest md=MessageDigest.getInstance("MD5");
            //计算MD5的值
            md.update(password.getBytes());
            //BigInteger将8位的字符串,转成16位的字符串,得到的字符串形式是哈希码值
            //BigInteger(参数1,参数2) 参数1 是1为正数 0位0 -1为负数
            return new BigInteger(1,md.digest()).toString(16);
        }catch (NoSuchAlgorithmException e){
            e.printStackTrace();
        }
        return null;
    }
}
