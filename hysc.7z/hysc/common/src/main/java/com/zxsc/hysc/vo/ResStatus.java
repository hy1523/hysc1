package com.zxsc.hysc.vo;

public class ResStatus {
    public static final int OK=10000;
    public static final int NO=10001;

    public static final int LOGIN_SUCCESS=20000; //登录认证成功

    public static final int LOHIN_FAIL_NOT=20001;//未登录

    public static final int LOHIN_FAIL_TIMEOUT=20002;// 登录过期

    public static final int LOHIN_FAIL_TOKEN=20003;//token不合法
}
