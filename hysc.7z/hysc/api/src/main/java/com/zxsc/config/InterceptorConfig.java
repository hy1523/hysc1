package com.zxsc.config;

import com.zxsc.interceptor.CheckTokenInterceptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;


//在是spring boot项目配置拦截器
@Configuration
public class InterceptorConfig implements WebMvcConfigurer {

    @Autowired
    private CheckTokenInterceptor checkTokenInterceptor;


    @Override
    public void addInterceptors(InterceptorRegistry registry){
        registry.addInterceptor(checkTokenInterceptor)  //将拦截器添加至MVC
                .addPathPatterns("/shopcart/**")     //设置拦截的路径
                .excludePathPatterns("/user/**");   //设置放行的路径
    }

}
