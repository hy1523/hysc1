package com.zxsc.controller;

import com.github.wxpay.sdk.WXPay;
import com.zxsc.config.MyPayConfig;
import com.zxsc.hysc.entity.Orders;
import com.zxsc.hysc.service.OrderService;
import com.zxsc.hysc.vo.ResStatus;
import com.github.wxpay.*;
import com.zxsc.hysc.vo.ResultVO;
import io.swagger.annotations.Api;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

@RestController
@CrossOrigin
@RequestMapping("/order")
@Api(value = "提供订单相关的操作接口",tags = "订单管理")
public class OrderController {

    @Autowired
    private OrderService orderService;

    @PostMapping("/add")
    public ResultVO add(String cids, @RequestBody Orders orders){
        ResultVO resultVO = orderService.addOrder(cids, orders);
        return resultVO;
    }


//    public void wxzf(){
        //微信支付：申请支付链接
        //         String orderId="123456789";
//        WXPay wePay = new WXPay( new MyPayConfig());
//        HashMap<String,String> data=new HashMap<>();
//        data.put("fee_type","CNY");//支付类型：人民币
//        data.put("total_free","9980");
//        data.put("out_trade_no",orderId);//订单编号
//        data.put("body","薰衣草");//支付金额
//        data.put("trade_type","NATIVE");//交易类型
        //data.put("notify_url","/pay/success");//设置完成时的回调路径
//
        //发送请求，获取响应
        //微信支付：申请支付链接

//
//        try {
//            Map<String, String> stringStringMap = wePay.unifiedOrder(data);
        // orderInfo.put("payUrl",resp.get("code_url"));
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

    @GetMapping("/list")
    public ResultVO getOrderList(int userId,int status){
        ResultVO orderByUserIdAndStatus = orderService.getOrderByUserIdAndStatus(userId, status);
        return orderByUserIdAndStatus;
    }
}
