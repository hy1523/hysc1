package com.zxsc.controller;


import com.zxsc.hysc.service.UserAddrService;
import com.zxsc.hysc.vo.ResultVO;
import io.swagger.annotations.Api;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Controller
@CrossOrigin
@RestController
@RequestMapping("/useraddr")
@Api(value = "提供收货地址的接口",tags = "收货地址管理")
public class UserAddrController {

    @Autowired
    private UserAddrService userAddrService;


    @GetMapping("/list")
    public ResultVO listAddrs(int userId){
        ResultVO resultVO = userAddrService.listAddrsByUid(userId);
        return resultVO;
    }
}
