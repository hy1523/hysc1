package com.zxsc.controller;

import com.zxsc.hysc.entity.Aduser;
import com.zxsc.hysc.entity.Usersc;
import com.zxsc.hysc.service.UserService;
import com.zxsc.hysc.vo.ResultVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

@Controller
@ResponseBody
@RequestMapping("/user")
@CrossOrigin
@Api(value = "提供用户的登录和注册",tags = "用户管理")
public class UserController {

    @Autowired
    private UserService userService;

    @ApiOperation("用户登录接口")
    @ApiImplicitParams({
            @ApiImplicitParam(dataType = "string",name = "username",value = "用户登录账户",required = true),
            @ApiImplicitParam(dataType = "string",name = "password",value = "用户登录密码",required = true)
    })
//    @RequestMapping(value = "/login",method = RequestMethod.POST)
//    public ResultVO Login(@RequestBody Aduser form){
//        return userService.checkLogin(form);
//    }
    @RequestMapping(value = "/login",method = RequestMethod.GET)
    public ResultVO Login(String username,String password){
        return userService.checkLogin(username,password);
    }


    @ApiOperation("用户注册接口")
    @ApiImplicitParams({
            @ApiImplicitParam(dataType = "string",name = "username",value = "用户注册账户",required = true),
            @ApiImplicitParam(dataType = "string",name = "password",value = "用户注册密码",required = true)
    })
    @PostMapping("regist")
    public ResultVO regist(@RequestBody Usersc user){
        ResultVO resultVO=userService.userResgit(user.getUsername(),user.getPassword());
        return resultVO;
    }

    @GetMapping("/getUser")
    public ResultVO selectUserById(int userId){
        ResultVO resultVO=userService.selectUserByUserId(userId);
        return resultVO;
    }
}
