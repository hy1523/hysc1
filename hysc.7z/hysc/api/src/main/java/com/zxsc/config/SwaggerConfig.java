package com.zxsc.config;

import org.springframework.context.annotation.Configuration;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;




@Configuration
@EnableSwagger2
public class SwaggerConfig {
    /*swagger帮助生成接口文档
    1,配置生成的文档信息
    2,配置生成规则
    */
    //Docket封装接口文档信息
    public Docket getDocket(){
       // Docket docket=new Docket(DocumentationType.SWAGGER_2);//制定文档风格

        //创建封面信息对象
        ApiInfoBuilder apiInfoBuilder=new ApiInfoBuilder();
        apiInfoBuilder.title("接口文档说明")
                .description("此文档说明了后端接口具体接口...")
                .version("v 2.0.1")
                .contact(new Contact("何洋","www.hy.com","2992550257@qq.com"));
        //如何获取一个接口对象
        //new接口,需要在构造器后的{},实现所有方法
        //new子类/实现类
        //工厂模式
        ApiInfo apiInfo=apiInfoBuilder.build();


        //docket.apiInfo(apiInfo);//制定生成的文档中封面信息:标题,作者,版本

        //链式调用: //
         Docket docket=new Docket(DocumentationType.SWAGGER_2)
                 .apiInfo(apiInfo)
                 .select()
                 .apis(RequestHandlerSelectors.basePackage("com.zxsc.controller"))//制定那些包生成文档
                 .paths(PathSelectors.regex("/user/"))//user开头的才会生成文档
                 .build();

        return docket;
    }
}
