package com.zxsc.controller;

import com.zxsc.hysc.entity.ShoppingCart;
import com.zxsc.hysc.service.ShoppingCartService;
import com.zxsc.hysc.vo.ResStatus;
import com.zxsc.hysc.vo.ResultVO;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.JwtParser;
import io.jsonwebtoken.Jwts;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import io.swagger.models.auth.In;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@ResponseBody
@RequestMapping("/shopcart")
@CrossOrigin
@Api(value = "提供购物车业务相关接口",tags = "购物车管理")
public class ShopcartController {

    @Autowired
    private ShoppingCartService shoppingCartService;

    @GetMapping("/list")
    @ApiImplicitParam(dataType = "string",value = "授权令牌",required = true)
    public ResultVO listCarts(String token){

        if(token ==null){
            return new ResultVO(ResStatus.NO,"请先登录",null);
        }
        else {
            //验证token
            JwtParser parser= Jwts.parser();
            parser.setSigningKey("hy123456"); //解析token中的SigningKey，必须和设置生成的密码一致

            //如果token正确（密码正确。有效期内）则正常执行，否则抛出异常
            try {
                Jws<Claims> claimsJws = parser.parseClaimsJws(token);

                Claims body=claimsJws.getBody();//获取token中的用户数据
                String subject=body.getSubject();//获取生成token设置的subject



                return new ResultVO(ResStatus.OK,"success",null);
            }catch (Exception e){
                return new ResultVO(ResStatus.NO,"登录过期，请重新登录！",null);
            }


        }

    }


    @PostMapping("/addShopping")
    public ResultVO addShopping(@RequestBody ShoppingCart cart,@RequestHeader("token")String token){
        ResultVO resultVO=shoppingCartService.addShoppingCart(cart);
        return resultVO;
    }

    @ApiOperation("购物车查询接口")
    @GetMapping("/shoppingCartList/{userId}")
    public ResultVO listShoppingCart(@PathVariable("userId") int userId){

        ResultVO resultVO=shoppingCartService.listShoppingCartByUserId(userId);

        return resultVO;
    }
    @ApiOperation("购物车修改接口")
    @PutMapping("/update/{cid}/{cnum}")
    public ResultVO updateNum(@PathVariable("cid") int cartId,
                              @PathVariable("cnum") int cartNum){

        ResultVO resultVO=shoppingCartService.updateCartNum(cartId,cartNum);

        return resultVO;
    }
    @ApiOperation("购物车删除接口")
    @GetMapping ("/delectCart/{cid}")
    public ResultVO updateNum(@PathVariable("cid") int cartId){

        ResultVO resultVO=shoppingCartService.delectCart(cartId);

        return resultVO;
    }

    @GetMapping ("/listbycids")
    @ApiImplicitParam(dataType = "String",name = "cids",value = "购物车记录Id",required = true)
    public ResultVO listByCids(String cids){

        ResultVO resultVO=shoppingCartService.listShoppingCartCids(cids);

        return resultVO;
    }
}
