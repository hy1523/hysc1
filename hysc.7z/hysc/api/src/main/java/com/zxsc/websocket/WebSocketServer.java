package com.zxsc.websocket;

import io.swagger.models.auth.In;
import org.springframework.stereotype.Component;

import javax.websocket.OnClose;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.PathParam;
import javax.websocket.server.ServerEndpoint;
import java.util.concurrent.ConcurrentHashMap;

@Component
@ServerEndpoint("/webSocket/{oid}")
public class WebSocketServer {

    private static ConcurrentHashMap<Integer,Session>   sessionMap=new ConcurrentHashMap<>();
//    前端发送请求，websocket连接，就会执行@OnOpen
    @OnOpen
    public void open(@PathParam("oid") int orderId, Session session){
        sessionMap.put(orderId,session);
    }

    //前端关闭页面，或主动关闭websocket
    @OnClose
    public void close(@PathParam("oid") Integer orderId ){
        sessionMap.remove(orderId);
    }
}
