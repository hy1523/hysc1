package com.zxsc.controller;



import com.zxsc.hysc.service.CategoryService;
import com.zxsc.hysc.service.IndexImgService;
import com.zxsc.hysc.service.ProductService;
import com.zxsc.hysc.vo.ResultVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@ResponseBody
@RequestMapping("/index")
@CrossOrigin
@Api(value = "提供首页的接口",tags = "首页接口")
public class IndexController {
    @Autowired
    private IndexImgService indexImgService;

    @Autowired
    private CategoryService categoryService;

    @Autowired
    private ProductService productService;

    @GetMapping("/indexImg")
    @ApiOperation("轮播图接口")
    public ResultVO listIndexImg(){
        return indexImgService.listIndexImg();
    }


    @GetMapping("/categoryList")
    @ApiOperation("分类列表接口")
    public ResultVO listCategory(){
        return categoryService.listCategories();
    }

    @GetMapping("/productList")
    @ApiOperation("推荐列表接口")
    public ResultVO listProduct(){
        return productService.SelectProduct();
    }


    @GetMapping("/allproductList")
    @ApiOperation("展示商品")
    public ResultVO listAllProduct(){
        return productService.SelectAllProduct();
    }


}
