package com.zxsc.config;

import com.github.wxpay.sdk.WXPayConfig;

import java.io.InputStream;

public class MyPayConfig implements WXPayConfig {
    @Override
    public String getAppID() {
        return null;
       // return "商户账号appID";
    }

    @Override
    public String getMchID() {
        return null;
        //return "商户编号";
    }

    @Override
    public String getKey() {
        return null;
        //return "商户Key";
    }

    @Override
    public InputStream getCertStream() {
        return null;
    }

    @Override
    public int getHttpConnectTimeoutMs() {
        return 0;
    }

    @Override
    public int getHttpReadTimeoutMs() {
        return 0;
    }
}
