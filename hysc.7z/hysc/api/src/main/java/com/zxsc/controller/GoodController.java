package com.zxsc.controller;

import com.zxsc.hysc.vo.ResultVO;
import org.springframework.web.bind.annotation.*;

//@Controller
//@ResponseBody
@RestController
@RequestMapping("/goods")
public class GoodController {
    //同一个路径,请求方式
    //post 添加
    //get 查询
    //put 修改
    // delete 删除
    // option 预检

//    @RequestMapping(value = "/add",method = RequestMethod.POST)
//    public ResultVO addGoods(){
//        return null;
//    }
//
    @PostMapping(  "/add")
    public ResultVO addGoods(){
        return null;
    }



    @RequestMapping(value = "/update",method = RequestMethod.PUT)
    public ResultVO updateGoods(){
        return null;
    }
//    @PutMapping( "/update")
//    public ResultVO updateGoods(){
//        return null;
//    }

    @RequestMapping(value = "/list",method = RequestMethod.GET)
    public ResultVO listGood(){
        return null;
    }

//    @GetMapping(  "/list")
//    public ResultVO listGood(){
//        return null;
//    }
    @GetMapping ( "/{id}")
    public ResultVO getGoods(@PathVariable("id") int goodsId){
        return null;
    }
    //请求路径:http://localhost:8080/goods/delete/1
    //       http://localhost:8080/goods/delete/1
    @DeleteMapping( "/{gid}")
    public ResultVO deleteGoods(@PathVariable("gid") int goodsId){
        System.out.println(goodsId);
        return new ResultVO(1000,"sds",null);
    }
//    @RequestMapping(value = "/delete/{gid}")
//    public ResultVO deleteGoods(@PathVariable("gid") int goodsId){
//        System.out.println(goodsId);
//        return new ResultVO(1000,"sds",null);
//    }
}
