package com.zxsc.controller;


import com.zxsc.hysc.service.ProductCommentsService;
import com.zxsc.hysc.service.ProductService;
import com.zxsc.hysc.vo.ResultVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin
@RequestMapping("/product")
@Api(value = "商品信息",tags = "商品管理")
public class ProductController {
    @Autowired
    private ProductService productService;

    @Autowired
    private ProductCommentsService productCommentsService;


    @ApiOperation("商品基本信息查询接口")
    @GetMapping("/detail-info/{pid}")
    public ResultVO getProductInfo(@PathVariable("pid") int pid){
        return productService.getProductInfo(pid);
    }

    @ApiOperation("商品参数信息查询接口")
    @GetMapping("/detail-params/{pid}")
    public ResultVO getProductParamsById(@PathVariable("pid") int pid){
        return productService.getProductParamsById(pid);
    }

    @ApiOperation("商品评论查询接口")
    @GetMapping("/detail-comment/{pid}")
    @ApiImplicitParams({
            @ApiImplicitParam(dataType = "int",name = "pageNum",value = "当前页码",required = true),
            @ApiImplicitParam(dataType = "int",name = "limit",value = "每页显示数量",required = true)
    })
    public ResultVO getProductComments(@PathVariable("pid") int pid,int pageNum,int limit){
        return productCommentsService.listCommentsByProductId(pid,pageNum,limit);
    }

    @ApiOperation("商品评价统计查询接口")
    @GetMapping("/detail-commentsCount/{pid}")
    public ResultVO getCommentCountByProductId(@PathVariable("pid") int pid){
        return productCommentsService.getCommentCountByProductId(pid);
    }

    @ApiOperation("商品通过名字查询接口")
    @GetMapping("/selectIdByName/{categoryName}")
    public ResultVO getIdByName(@PathVariable("categoryName") String categoryName){
        return productService.getProductIdByName(categoryName);
    }

}
