package com.zxsc.hysc.dao;

import com.zxsc.hysc.entity.Product;
import com.zxsc.hysc.entity.ProductVO;
import com.zxsc.hysc.genera.GeneratorDAO;
import org.apache.ibatis.annotations.Delete;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProductMapper extends GeneratorDAO<Product> {
    public List<ProductVO> SelectProductList();

    public List<ProductVO> SelectAllProductList();

    public int SelectProductIdByName(String categoryName);

}