package com.zxsc.hysc.dao;

import com.zxsc.hysc.entity.ProductImg;
import com.zxsc.hysc.genera.GeneratorDAO;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public interface ProductImgMapper extends GeneratorDAO<ProductImg> {
    public List<ProductImg> SelectProductImgByProductId(int productId);
}