package com.zxsc.hysc.dao;

import com.zxsc.hysc.entity.Orders;
import com.zxsc.hysc.genera.GeneratorDAO;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface OrdersMapper extends GeneratorDAO<Orders> {
    public List<Orders> selectOrderListByUserIdAndStatus(@Param("userId")int userId,@Param("status")int status);
}