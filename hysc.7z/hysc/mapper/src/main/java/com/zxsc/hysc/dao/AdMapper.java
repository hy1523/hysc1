package com.zxsc.hysc.dao;

import com.zxsc.hysc.entity.Aduser;
import com.zxsc.hysc.genera.GeneratorDAO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

@Repository
@Mapper
public interface AdMapper {

    @Select("select * from aduser where username=#{name}")
    public Aduser selectByname(String name);



}
