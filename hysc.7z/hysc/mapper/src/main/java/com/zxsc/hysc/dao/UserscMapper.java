package com.zxsc.hysc.dao;

import com.sun.javaws.jnl.ResourceVisitor;
import com.zxsc.hysc.entity.Usersc;
import com.zxsc.hysc.genera.GeneratorDAO;
import org.springframework.stereotype.Repository;

@Repository
public interface UserscMapper extends GeneratorDAO<Usersc> {

    public int updateImgByUserId(int userId,String file);
}