package com.zxsc.hysc.genera;

import tk.mybatis.mapper.common.Mapper;
import tk.mybatis.mapper.common.MySqlMapper;

public interface GeneratorDAO<T> extends Mapper<T> , MySqlMapper<T> {
}
