package com.zxsc.hysc.dao;

import com.zxsc.hysc.entity.ShoppingCart;
import com.zxsc.hysc.entity.ShoppingCartVO;
import com.zxsc.hysc.genera.GeneratorDAO;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ShoppingCartMapper extends GeneratorDAO<ShoppingCart> {
    public List<ShoppingCartVO> selectShopcartByUserId(int userId);

    public int updateCartNumByCartId(@Param("cartId") int cartId,
                                     @Param("cartNum") int cartNum);

    public List<ShoppingCartVO> selectShoppingByCids(List<Integer> cartIds);
}