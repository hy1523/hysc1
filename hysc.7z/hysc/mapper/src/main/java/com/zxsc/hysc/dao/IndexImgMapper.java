package com.zxsc.hysc.dao;

import com.zxsc.hysc.entity.IndexImg;
import com.zxsc.hysc.genera.GeneratorDAO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IndexImgMapper extends GeneratorDAO<IndexImg> {
    //查询轮播图信息，查询status=1，按照seq进行排序
    public List<IndexImg> listIndexImg();
}