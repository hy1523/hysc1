package com.zxsc.hysc.dao;

import com.zxsc.hysc.entity.UserLoginHistory;
import com.zxsc.hysc.genera.GeneratorDAO;

public interface UserLoginHistoryMapper extends GeneratorDAO<UserLoginHistory> {
}