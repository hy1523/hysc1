package com.zxsc.hysc.dao;

import com.zxsc.hysc.entity.ProductParams;
import com.zxsc.hysc.genera.GeneratorDAO;
import org.springframework.stereotype.Repository;

@Repository
public interface ProductParamsMapper extends GeneratorDAO<ProductParams> {
}