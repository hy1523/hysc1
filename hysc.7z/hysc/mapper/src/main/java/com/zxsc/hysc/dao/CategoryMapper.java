package com.zxsc.hysc.dao;

import com.zxsc.hysc.entity.Category;
import com.zxsc.hysc.entity.CategoryVo;
import com.zxsc.hysc.genera.GeneratorDAO;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CategoryMapper extends GeneratorDAO<Category> {
    public List<CategoryVo> selectCategoryList();


}