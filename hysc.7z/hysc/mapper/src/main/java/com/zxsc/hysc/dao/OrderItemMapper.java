package com.zxsc.hysc.dao;

import com.zxsc.hysc.entity.OrderItem;
import com.zxsc.hysc.genera.GeneratorDAO;
import org.springframework.stereotype.Repository;

@Repository
public interface OrderItemMapper extends GeneratorDAO<OrderItem> {
}