package com.zxsc.hysc.dao;

import com.zxsc.hysc.entity.ProductComments;
import com.zxsc.hysc.entity.ProductCommentsVo;
import com.zxsc.hysc.genera.GeneratorDAO;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProductCommentsMapper extends GeneratorDAO<ProductComments> {

    public List<ProductCommentsVo> selectCommentsByProductId(@Param("productId") int productId,
                                                             @Param("start") int start,
                                                             @Param("limit") int limit);
}