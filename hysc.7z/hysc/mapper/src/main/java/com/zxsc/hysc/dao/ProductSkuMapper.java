package com.zxsc.hysc.dao;

import com.zxsc.hysc.entity.ProductSku;
import com.zxsc.hysc.genera.GeneratorDAO;
import org.springframework.stereotype.Repository;

@Repository
public interface ProductSkuMapper extends GeneratorDAO<ProductSku> {
}